// Arco Solar — skin, burn time and vitamin D estimates
// All figures here are educational approximations (Fitzpatrick-scale minutes-
// to-burn at UV=1, scaled by SPF). They are not medical guidance.
(function(global){
  const SKIN_TYPES = [
    { id:1, label:'I',   base:150, hex:'#F4DFC9', dark:0 },
    { id:2, label:'II',  base:250, hex:'#E8C79C', dark:0 },
    { id:3, label:'III', base:350, hex:'#D2A374', dark:0 },
    { id:4, label:'IV',  base:450, hex:'#AD7A4C', dark:1 },
    { id:5, label:'V',   base:600, hex:'#7A5030', dark:1 },
    { id:6, label:'VI',  base:750, hex:'#4A2E1C', dark:1 },
  ];
  function skinDescKey(id){
    return { 1:'skinDesc1', 2:'skinDesc2', 3:'skinDesc3', 4:'skinDesc4', 5:'skinDesc5', 6:'skinDesc6' }[id];
  }

  // SPF options: extension factor is a simplified, conservative approximation
  // (real-world protection depends heavily on correct/re-application).
  const SPF_OPTIONS = [
    { spf: 0,  label:'—',   factor: 1 },
    { spf: 15, label:'15',  factor: 5 },
    { spf: 30, label:'30',  factor: 8 },
    { spf: 50, label:'50+', factor: 12 },
  ];

  function burnMinutes(skinId, uv, spf){
    const skin = SKIN_TYPES.find(s=>s.id===skinId) || SKIN_TYPES[2];
    const opt = SPF_OPTIONS.find(o=>o.spf===spf) || SPF_OPTIONS[0];
    return Math.round((skin.base * opt.factor) / Math.max(uv, 0.3));
  }

  // Very rough vitamin D estimate: assumes ~600 IU produced per 10 minutes of
  // mid-UV (index ~5) exposure on ~25% of skin, scaled linearly with UV and
  // exposure minutes, halved when sunscreen is in use. Purely illustrative.
  function vitaminDEstimate(uv, minutesExposed, spf){
    const base = (uv / 5) * (minutesExposed / 10) * 600;
    const factor = spf > 0 ? 0.4 : 1;
    return Math.max(0, Math.round(base * factor));
  }

  global.SkinModel = { SKIN_TYPES, SPF_OPTIONS, skinDescKey, burnMinutes, vitaminDEstimate };
})(window);
