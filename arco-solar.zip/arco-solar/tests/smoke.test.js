// Arco Solar — smoke tests
// Loads the REAL index.html (and its real js/*.js files) through jsdom,
// mocks only the network/browser boundary (fetch, geolocation, localStorage),
// and drives the actual UI through clicks — the same code path a real user
// hits in a real browser. Run with: npm test
const { JSDOM } = require('jsdom');
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const ROOT = path.join(__dirname, '..');
const now = new Date();

function fakeForecast(){
  const hourly_time = [], uv_index = [];
  const todayISO = now.toISOString().slice(0,10);
  for(let h=0; h<24; h++){
    hourly_time.push(`${todayISO}T${String(h).padStart(2,'0')}:00`);
    uv_index.push(h>6 && h<19 ? 6 : 0);
  }
  const daily_time=[], daily_max=[], sunrise=[], sunset=[];
  for(let d=0; d<10; d++){
    const dd = new Date(now); dd.setDate(now.getDate()+d);
    const ds = dd.toISOString().slice(0,10);
    daily_time.push(ds); daily_max.push(7.5);
    sunrise.push(`${ds}T07:10`); sunset.push(`${ds}T20:45`);
  }
  return { utc_offset_seconds: 3600,
    hourly: { time: hourly_time, uv_index },
    daily: { time: daily_time, uv_index_max: daily_max, sunrise, sunset } };
}

let networkMode = 'ok'; // 'ok' | 'fail'

async function loadApp(){
  const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  let ls = {};
  const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    resources: 'usable',
    url: `file://${ROOT}/index.html`,
    pretendToBeVisual: true,
    beforeParse(window){
      window.fetch = async (url) => {
        if(networkMode === 'fail') throw new Error('network down');
        if(url.includes('geocoding')){
          if(url.includes('Atlantis')) return { ok:true, json: async ()=>({results:[]}) };
          return { ok:true, json: async ()=>({results:[{latitude:39.6,longitude:-9.07,name:'Nazaré',country:'Portugal'}]}) };
        }
        return { ok:true, json: async ()=>fakeForecast() };
      };
      window.navigator.geolocation = undefined;
      window.navigator.vibrate = () => {};
      Object.defineProperty(window.navigator, 'language', { value: 'pt-PT', configurable: true });
      Object.defineProperty(window, 'localStorage', {
        configurable: true,
        value: {
          getItem: k => (k in ls ? ls[k] : null),
          setItem: (k,v) => { ls[k]=v; },
          removeItem: k => { delete ls[k]; }
        }
      });
      window.HTMLCanvasElement.prototype.getContext = () => ({
        scale(){}, clearRect(){}, fillRect(){},
      });
    }
  });
  const errors = [];
  dom.window.onerror = (msg) => errors.push(msg);
  dom.window.addEventListener('unhandledrejection', e => errors.push(String(e.reason)));
  await new Promise(r => setTimeout(r, 400));
  return { dom, errors, ls };
}

function click(dom, id){
  const node = dom.window.document.getElementById(id);
  node.dispatchEvent(new dom.window.MouseEvent('click', { bubbles:true }));
}
function q(dom, sel){ return dom.window.document.querySelector(sel); }
function qa(dom, sel){ return [...dom.window.document.querySelectorAll(sel)]; }

let passed = 0, failed = 0;
async function test(name, fn){
  try{ await fn(); console.log(`  ok  - ${name}`); passed++; }
  catch(e){ console.log(`FAIL - ${name}\n       ${e.message}`); failed++; }
}

(async () => {
  console.log('Arco Solar — smoke tests\n');

  await test('renders the current UV without runtime errors', async () => {
    const { dom, errors } = await loadApp();
    assert.strictEqual(errors.length, 0, `unexpected errors: ${errors.join(', ')}`);
    const html = q(dom, '#app').innerHTML;
    assert.ok(html.includes('bignum'), 'hero UV number missing');
    assert.ok(html.includes('Nazaré'), 'place name missing');
  });

  await test('switching to the Skin tab shows skin types and SPF options', async () => {
    const { dom } = await loadApp();
    qa(dom, '.tab').find(t => t.dataset.tab === 'skin').click();
    await new Promise(r=>setTimeout(r,50));
    const swatches = qa(dom, '.swatch');
    const spfChips = qa(dom, '.spfchip');
    assert.strictEqual(swatches.length, 6, 'expected 6 skin type swatches');
    assert.strictEqual(spfChips.length, 4, 'expected 4 SPF options');
  });

  await test('selecting a skin type persists to storage and updates burn time', async () => {
    const { dom, ls } = await loadApp();
    qa(dom, '.tab').find(t => t.dataset.tab === 'skin').click();
    await new Promise(r=>setTimeout(r,50));
    const swatch1 = qa(dom, '.swatch').find(s => s.dataset.skin === '1');
    swatch1.click();
    await new Promise(r=>setTimeout(r,50));
    assert.strictEqual(JSON.parse(ls['arcoSolar.skin']), 1, 'skin choice not persisted');
    const active = q(dom, '.swatch.active');
    assert.strictEqual(active.dataset.skin, '1', 'active swatch not reflected in DOM');
  });

  await test('selecting an SPF option persists and changes burn-time card', async () => {
    const { dom, ls } = await loadApp();
    qa(dom, '.tab').find(t => t.dataset.tab === 'skin').click();
    await new Promise(r=>setTimeout(r,50));
    const before = q(dom, '.burnnum').textContent;
    const spf30 = qa(dom, '.spfchip').find(c => c.dataset.spf === '30');
    spf30.click();
    await new Promise(r=>setTimeout(r,50));
    assert.strictEqual(JSON.parse(ls['arcoSolar.spf']), 30, 'SPF choice not persisted');
    const after = q(dom, '.burnnum').textContent;
    assert.notStrictEqual(before, after, 'burn-time estimate did not change with SPF');
  });

  await test('routine timer: start shows a countdown and Pausar label', async () => {
    const { dom } = await loadApp();
    click(dom, 'startBtn');
    const disp = q(dom, '#timerDisplay').textContent;
    assert.match(disp, /^\d{2}:\d{2}$/, 'timer display not showing a countdown');
    assert.strictEqual(q(dom, '#startBtn').textContent, 'Pausar');
  });

  await test('routine timer: pause then resume toggles the label correctly', async () => {
    const { dom } = await loadApp();
    click(dom, 'startBtn'); // start
    click(dom, 'startBtn'); // pause
    assert.strictEqual(q(dom, '#startBtn').textContent, 'Continuar');
    click(dom, 'startBtn'); // resume
    assert.strictEqual(q(dom, '#startBtn').textContent, 'Pausar');
  });

  await test('routine timer: reset returns to idle state', async () => {
    const { dom } = await loadApp();
    click(dom, 'startBtn');
    click(dom, 'resetBtn');
    assert.strictEqual(q(dom, '#timerDisplay').textContent, '--:--');
    assert.strictEqual(q(dom, '#startBtn').textContent, 'Começar');
  });

  await test('changing skin type mid-run does not reset the visible countdown', async () => {
    const { dom } = await loadApp();
    click(dom, 'startBtn');
    const before = q(dom, '#timerDisplay').textContent;
    qa(dom, '.tab').find(t => t.dataset.tab === 'skin').click();
    await new Promise(r=>setTimeout(r,30));
    qa(dom, '.swatch').find(s => s.dataset.skin === '2').click();
    await new Promise(r=>setTimeout(r,30));
    qa(dom, '.tab').find(t => t.dataset.tab === 'today').click();
    await new Promise(r=>setTimeout(r,30));
    const after = q(dom, '#timerDisplay').textContent;
    assert.strictEqual(before, after, `expected timer to stay at ${before}, got ${after}`);
    assert.strictEqual(q(dom, '#startBtn').textContent, 'Pausar', 'timer should still be running');
  });

  await test('city search finds a known city with no errors', async () => {
    const { dom, errors } = await loadApp();
    q(dom, '#cityInput').value = 'Nazaré';
    click(dom, 'goBtn');
    await new Promise(r=>setTimeout(r,200));
    assert.strictEqual(errors.length, 0, `unexpected errors: ${errors.join(', ')}`);
    assert.ok(q(dom, '#app').innerHTML.includes('Nazaré'));
  });

  await test('city search shows a clear message for an unknown city', async () => {
    const { dom } = await loadApp();
    q(dom, '#cityInput').value = 'Atlantis';
    click(dom, 'goBtn');
    await new Promise(r=>setTimeout(r,200));
    assert.ok(q(dom, '#app').innerHTML.includes('não encontrada'));
  });

  await test('falls back to the offline estimate when the network fails, without crashing', async () => {
    networkMode = 'fail';
    const { dom, errors } = await loadApp();
    networkMode = 'ok';
    assert.strictEqual(errors.length, 0, `unexpected errors: ${errors.join(', ')}`);
    assert.ok(q(dom, '#app').innerHTML.includes('bignum'), 'app should still render a UV value in offline mode');
  });

  await test('language switch updates visible UI text', async () => {
    const { dom } = await loadApp();
    const sel = q(dom, '#langSelect');
    sel.value = 'en';
    sel.dispatchEvent(new dom.window.Event('change', { bubbles:true }));
    await new Promise(r=>setTimeout(r,50));
    assert.ok(q(dom, '#goBtn').textContent.includes('Search'), 'expected English label after language switch');
  });

  await test('onboarding overlay appears on first run and can be dismissed', async () => {
    const { dom } = await loadApp();
    const overlay = q(dom, '.onboard-overlay');
    assert.ok(overlay, 'onboarding overlay should appear on first run');
    const skipBtn = q(dom, '#obSkip');
    skipBtn.click();
    assert.strictEqual(q(dom, '.onboard-overlay'), null, 'onboarding overlay should close after skip');
  });

  await test('onboarding does not reappear once dismissed (persisted)', async () => {
    const first = await loadApp();
    q(first.dom, '#obSkip').click();
    const ls = first.ls;
    const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
    const dom2 = new JSDOM(html, {
      runScripts:'dangerously', resources:'usable', url:`file://${ROOT}/index.html`,
      beforeParse(window){
        window.fetch = async () => ({ ok:true, json: async ()=>fakeForecast() });
        Object.defineProperty(window, 'localStorage', {
          configurable: true,
          value: {
            getItem: k=>(k in ls?ls[k]:null),
            setItem: (k,v)=>{ls[k]=v;},
            removeItem: k=>{delete ls[k];}
          }
        });
        window.HTMLCanvasElement.prototype.getContext = () => ({ scale(){}, clearRect(){}, fillRect(){} });
      }
    });
    await new Promise(r=>setTimeout(r,300));
    assert.strictEqual(q(dom2, '.onboard-overlay'), null, 'onboarding should not reappear after being dismissed once');
  });

  await test('history tab shows empty state before any session, and share button appears after one', async () => {
    const { dom, ls } = await loadApp();
    qa(dom, '.tab').find(t => t.dataset.tab === 'history').click();
    await new Promise(r=>setTimeout(r,50));
    assert.ok(q(dom, '#app').innerHTML.includes('historyempty') || q(dom,'.historyempty'), 'expected empty history state');

    // simulate a completed routine by writing a history entry directly (as timer.js onComplete would)
    const list = JSON.parse(ls['arcoSolar.history'] || '[]');
    list.push({ ts: Date.now(), uv: 6, skinId: 3, spf: 0, totalMinutes: 45 });
    ls['arcoSolar.history'] = JSON.stringify(list);
    qa(dom, '.tab').find(t => t.dataset.tab === 'today').click();
    qa(dom, '.tab').find(t => t.dataset.tab === 'history').click();
    await new Promise(r=>setTimeout(r,50));
    assert.ok(q(dom, '#shareBtn'), 'share button should appear once history has an entry');
  });

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
